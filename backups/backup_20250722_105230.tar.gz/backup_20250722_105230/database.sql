-- MySQL dump 10.13  Distrib 8.0.42, for Linux (aarch64)
--
-- Host: localhost    Database: anchor_db_42
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Court Decisions','Federal and state court decisions affecting immigration law','2025-07-21 19:22:22','2025-07-21 19:22:22'),(2,'Administrative Guidance','USCIS, ICE, and CBP policy memos and guidance documents','2025-07-21 19:22:22','2025-07-21 19:22:22'),(3,'Legislative History','Congressional records and legislative intent documentation','2025-07-21 19:22:22','2025-07-21 19:22:22'),(4,'International Law','Treaties, international agreements, and comparative law','2025-07-21 19:22:22','2025-07-21 19:22:22'),(5,'Academic Research','Peer-reviewed studies and academic analysis','2025-07-21 19:22:22','2025-07-21 19:22:22'),(6,'Advocacy Reports','Reports from immigrant rights organizations','2025-07-21 19:22:22','2025-07-21 19:22:22'),(7,'Government Data','Official statistics and government-published data','2025-07-21 19:22:22','2025-07-21 19:22:22'),(8,'Case Studies','Detailed analysis of specific immigration cases','2025-07-21 19:22:22','2025-07-21 19:22:22'),(9,'Historical Context','Historical background and precedent information','2025-07-21 19:22:22','2025-07-21 19:22:22'),(10,'Regional Variations','State and local policy differences','2025-07-21 19:22:22','2025-07-21 19:22:22'),(11,'Procedural Guidance','Step-by-step process documentation','2025-07-21 19:22:22','2025-07-21 19:22:22'),(12,'Rights Information','Know-your-rights materials and resources','2025-07-21 19:22:22','2025-07-21 19:22:22');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evidence`
--

DROP TABLE IF EXISTS `evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evidence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` text,
  `content` longtext,
  `source_url` varchar(500) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_evidence_user_id` (`user_id`),
  KEY `idx_evidence_created_at` (`created_at`),
  CONSTRAINT `evidence_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evidence`
--

LOCK TABLES `evidence` WRITE;
/*!40000 ALTER TABLE `evidence` DISABLE KEYS */;
INSERT INTO `evidence` VALUES (1,'Sample Legal Precedent','This is a test evidence entry for legal precedent category','Detailed content about this legal case and its implications for immigration law...','https://example.com/legal-case-1',2,'2025-07-21 19:22:22','2025-07-21 19:22:22'),(2,'Immigration Policy Analysis 2024','Analysis of recent policy changes and their impact','Comprehensive analysis of policy changes implemented in 2024...','https://example.com/policy-analysis-2024',2,'2025-07-21 19:22:22','2025-07-21 19:22:22'),(3,'Statistical Report on Asylum Cases','Government data on asylum case outcomes','Statistical breakdown of asylum case approvals and denials...','https://example.com/asylum-stats',3,'2025-07-21 19:22:22','2025-07-21 19:22:22'),(4,'Personal Immigration Story','First-hand account of immigration process','Personal narrative describing the challenges and successes...',NULL,4,'2025-07-21 19:22:22','2025-07-21 19:22:22');
/*!40000 ALTER TABLE `evidence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evidencecategorylink`
--

DROP TABLE IF EXISTS `evidencecategorylink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evidencecategorylink` (
  `id` int NOT NULL AUTO_INCREMENT,
  `evidence_id` int NOT NULL,
  `category_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_evidence_category` (`evidence_id`,`category_id`),
  KEY `idx_evidencecategorylink_evidence_id` (`evidence_id`),
  KEY `idx_evidencecategorylink_category_id` (`category_id`),
  CONSTRAINT `evidencecategorylink_ibfk_1` FOREIGN KEY (`evidence_id`) REFERENCES `evidence` (`id`) ON DELETE CASCADE,
  CONSTRAINT `evidencecategorylink_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evidencecategorylink`
--

LOCK TABLES `evidencecategorylink` WRITE;
/*!40000 ALTER TABLE `evidencecategorylink` DISABLE KEYS */;
INSERT INTO `evidencecategorylink` VALUES (1,1,1,'2025-07-21 19:22:22'),(2,2,2,'2025-07-21 19:22:22'),(3,3,3,'2025-07-21 19:22:22'),(4,4,4,'2025-07-21 19:22:22'),(5,1,7,'2025-07-21 19:22:22'),(6,2,8,'2025-07-21 19:22:22'),(7,3,12,'2025-07-21 19:22:22');
/*!40000 ALTER TABLE `evidencecategorylink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(80) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'m','m@test.com','111',1,'2025-07-21 19:22:22','2025-07-21 19:22:22'),(2,'v','v@test.com','222',0,'2025-07-21 19:22:22','2025-07-21 19:22:22'),(3,'c','c@test.com','222',0,'2025-07-21 19:22:22','2025-07-21 19:22:22'),(4,'dl','dl@test.com','222',0,'2025-07-21 19:22:22','2025-07-21 19:22:22'),(5,'custom_user','custom@example.com','custom_password_hash',0,'2025-07-21 19:23:35','2025-07-21 19:23:35');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vote`
--

DROP TABLE IF EXISTS `vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vote` (
  `id` int NOT NULL AUTO_INCREMENT,
  `evidence_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `vote_type` enum('up','down') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_evidence_vote` (`user_id`,`evidence_id`),
  KEY `idx_vote_evidence_id` (`evidence_id`),
  KEY `idx_vote_user_id` (`user_id`),
  CONSTRAINT `vote_ibfk_1` FOREIGN KEY (`evidence_id`) REFERENCES `evidence` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vote_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vote`
--

LOCK TABLES `vote` WRITE;
/*!40000 ALTER TABLE `vote` DISABLE KEYS */;
INSERT INTO `vote` VALUES (1,1,2,'up','2025-07-21 19:22:22','2025-07-21 19:22:22'),(2,1,3,'up','2025-07-21 19:22:22','2025-07-21 19:22:22'),(3,2,2,'up','2025-07-21 19:22:22','2025-07-21 19:22:22'),(4,2,4,'down','2025-07-21 19:22:22','2025-07-21 19:22:22'),(5,3,3,'up','2025-07-21 19:22:22','2025-07-21 19:22:22'),(6,4,2,'up','2025-07-21 19:22:22','2025-07-21 19:22:22'),(7,4,3,'up','2025-07-21 19:22:22','2025-07-21 19:22:22');
/*!40000 ALTER TABLE `vote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'anchor_db_42'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-22 15:52:30
